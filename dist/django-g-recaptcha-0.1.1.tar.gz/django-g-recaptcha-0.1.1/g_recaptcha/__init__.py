# -*- coding: utf-8 -
#
# g-recaptcha-validate is realease under a Creative Commons license

version_info = (0, 1)
__version__ = ".".join([str(v) for v in version_info])