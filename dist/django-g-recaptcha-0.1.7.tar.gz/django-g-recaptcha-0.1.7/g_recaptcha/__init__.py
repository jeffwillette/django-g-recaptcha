# -*- coding: utf-8 -
#
# g-recaptcha-validate is realease under a Creative Commons license